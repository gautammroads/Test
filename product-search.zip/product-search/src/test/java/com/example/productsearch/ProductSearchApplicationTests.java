package com.example.productsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
